package com.example.sms

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
