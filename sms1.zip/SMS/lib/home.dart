import 'package:flutter/material.dart';
import 'service_screen.dart'; // Import the second screen for service selection

class home extends StatefulWidget {
  const home({super.key});

  @override
  State<home> createState() => _homeState();
}

class _homeState extends State<home> {
  List<Map<String, String>> addedServices = []; // Store added services

  // Function to add selected service to the list
  void _addService(String serviceName, String serviceIcon) {
    setState(() {
      addedServices.add({
        'name': serviceName,
        'icon': serviceIcon,
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue.shade50,
      appBar: AppBar(
        leading: const Icon(Icons.settings, color: Colors.black),
        actions: const [Icon(Icons.notifications, color: Colors.black)],
        title: const Text(
          'Subscription Management',
          style: TextStyle(color: Colors.black),
        ),
        backgroundColor: Colors.blue.shade200,
        elevation: 4,
      ),
      body: SingleChildScrollView(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 16),
              const Text(
                'Your Services:',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black87),
              ),
              const SizedBox(height: 8),

              // Horizontal Scrollable Row
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    // Add Service Card with "+" icon
                    ServiceCard(
                      title: 'Add Service',
                      iconPath: "images/plus_icon.png", // Plus icon
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ServiceScreen(
                            onServiceSelected: _addService,
                          ),
                        ),
                      ),
                      isAddServiceCard: true, // Flag to indicate this is the add service card
                    ),
                    // Dynamically show added services next to Add Service
                    for (var service in addedServices)
                      ServiceCard(
                        title: service['name']!,
                        iconPath: service['icon']!,
                        onTap: () {},
                        isAddServiceCard: false, // No "+" icon for added services
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // Popular Services Section (showing only 4 services)
              const Text(
                'Popular Services:',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black87),
              ),
              const SizedBox(height: 10),
              PopularServices(),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ServiceScreen(
              onServiceSelected: _addService,
            ),
          ),
        ),
        backgroundColor: Colors.blue.shade600,
        child: const Icon(Icons.add, color: Colors.white),
      ),
    );
  }
}

class ServiceCard extends StatelessWidget {
  final String title;
  final String iconPath;
  final VoidCallback onTap;
  final bool isAddServiceCard; // Flag to check if this is the add service card

  const ServiceCard({
    super.key,
    required this.title,
    required this.iconPath,
    required this.onTap,
    required this.isAddServiceCard,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        height: 120,
        width: 120,
        margin: const EdgeInsets.only(right: 12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 6,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Only show "+" icon for the Add Service card
            if (isAddServiceCard)
              const Icon(
                Icons.add,
                size: 50,
                color: Colors.blue,
              )
            else
              ImageIcon(
                AssetImage(iconPath),
                size: 50,
                color: Colors.blue.shade700,
              ),
            const SizedBox(height: 8),
            Text(
              title,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class PopularServices extends StatelessWidget {
  final List<Map<String, String>> services = [
    {"name": "Amazon Prime", "icon": "images/a2.png"},
    {"name": "Spotify", "icon": "images/s.png"},
    {"name": "YouTube", "icon": "images/y.png"},
    {"name": "Google One", "icon": "images/one.png"},
  ];

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: services.map((service) {
          return ServiceCard(
            title: service['name']!,
            iconPath: service['icon']!,
            onTap: () {},
            isAddServiceCard: false, // No "+" icon for popular services
          );
        }).toList(),
      ),
    );
  }
}
