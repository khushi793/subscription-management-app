import 'package:flutter/material.dart';

class ServiceScreen extends StatelessWidget {
  final Function(String, String) onServiceSelected;

  ServiceScreen({Key? key, required this.onServiceSelected}) : super(key: key);

  final List<Map<String, String>> services = [
    {"name": "Amazon Prime", "icon": "images/a2.png"},
    {"name": "Spotify", "icon": "images/s.png"},
    {"name": "YouTube", "icon": "images/y.png"},
    {"name": "Google One", "icon": "images/one.png"},
    {"name": "Xbox", "icon": "images/xbox.png"},
    // Add more services as needed
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Select Service'),
        backgroundColor: Colors.blue.shade200,
        elevation: 4,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: GridView.builder(
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 16.0,
            mainAxisSpacing: 16.0,
            childAspectRatio: 1.2,
          ),
          itemCount: services.length,
          itemBuilder: (context, index) {
            return _buildServiceCard(
              context,
              services[index]['name']!,
              services[index]['icon']!,
            );
          },
        ),
      ),
    );
  }

  Widget _buildServiceCard(BuildContext context, String serviceName, String iconPath) {
    return InkWell(
      onTap: () {
        _showSubscriptionPopup(context, serviceName, iconPath);
      },
      child: Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        elevation: 6,
        shadowColor: Colors.black.withOpacity(0.2),
        color: Colors.white,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: Stack(
            children: [
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.blue.shade200, Colors.blue.shade50],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Image.asset(
                      iconPath,
                      width: 60,
                      height: 60,
                    ),
                    const SizedBox(height: 10),
                    Text(
                      serviceName,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.blue.shade700,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Function to show subscription plan popup
  void _showSubscriptionPopup(BuildContext context, String serviceName, String serviceIcon) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('$serviceName Subscription Plans'),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildSubscriptionOption(context, '1 Month', '₹ 500', serviceName, serviceIcon),
              _buildSubscriptionOption(context, '3 Months', '₹ 1200', serviceName, serviceIcon),
              _buildSubscriptionOption(context, '1 Year', '₹ 4500', serviceName, serviceIcon),
            ],
          ),
        );
      },
    );
  }

  // Subscription option widget
  Widget _buildSubscriptionOption(
      BuildContext context, String plan, String price, String serviceName, String serviceIcon) {
    return InkWell(
      onTap: () {
        _selectPlan(context, serviceName, serviceIcon, plan, price);
      },
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              plan,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
            ),
            Text(
              price,
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.blue.shade700),
            ),
          ],
        ),
      ),
    );
  }

  // Function to select the subscription plan and send the service back to home screen
  void _selectPlan(BuildContext context, String serviceName, String serviceIcon, String plan, String price) {
    // Notify home screen with the selected service and plan
    onServiceSelected(serviceName, serviceIcon);

    // Close the popup and navigate back to home screen
    Navigator.pop(context); // Close the dialog
    Navigator.pop(context); // Close the ServiceScreen
  }
}
