/// Library for Emoji
///
/// The class [Emoji] contains emoji data with some modification methods.
library emoji;

export 'src/emoji.dart';
