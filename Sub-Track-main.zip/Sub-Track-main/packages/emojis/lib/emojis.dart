/// Library for Unicode Emojis
///
/// Class [Emojis] contains all emojis character.
library emojis;

export 'src/unicode_emojis.dart';
