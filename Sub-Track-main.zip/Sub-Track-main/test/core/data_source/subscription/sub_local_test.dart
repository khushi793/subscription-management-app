import 'package:flutter_test/flutter_test.dart';

void main() {
  test("should add Subscription to Local and Remote", () async {});
}
