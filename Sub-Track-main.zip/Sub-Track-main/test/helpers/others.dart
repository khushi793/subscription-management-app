part of 'test_helpers.dart';

HiveInterface getAndRegisterHiveInterface() {
  _removeRegistrationIfExists<HiveInterface>();
  final service = HiveImpl.test();
  locator.registerSingleton<HiveInterface>(service);
  return service;
}

UIServices getAndRegisterUIServices() {
  _removeRegistrationIfExists<UIServices>();
  final service = MockUIServices();
  locator.registerSingleton<UIServices>(service);
  return service;
}
