part of 'resources.dart';

class SvgAssets {
  SvgAssets._();

  static const String mobile2 = 'assets/images/svg/mobile_2.svg';
  static const String mobile1 = 'assets/images/svg/mobile_1.svg';
  static const String boy2 = 'assets/images/svg/boy_2.svg';
  static const String boy3 = 'assets/images/svg/boy_3.svg';
  static const String notificatons = 'assets/images/svg/notificatons.svg';
  static const String boy1 = 'assets/images/svg/boy_1.svg';
}
