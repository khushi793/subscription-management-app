part of 'resources.dart';

class AppIconsAssets {
  AppIconsAssets._();

  static const String googleDark = 'assets/appIcons/google_dark.png';
  static const String facebookDark = 'assets/appIcons/facebook_dark.png';
  static const String apple = 'assets/appIcons/apple.png';
  static const String google = 'assets/appIcons/google.png';
  static const String facebook = 'assets/appIcons/facebook.png';
}
