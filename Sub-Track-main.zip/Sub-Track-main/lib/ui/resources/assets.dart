part of 'resources.dart';

class Assets {
  Assets._();

  static const String notificatons = 'assets/images/3x/notificatons.png';
  static const String boy1 = 'assets/images/3x/boy_1.png';
  static const String boy3 = 'assets/images/3x/boy_3.png';
  static const String boy2 = 'assets/images/3x/boy_2.png';
  static const String mobile1 = 'assets/images/3x/mobile_1.png';
  static const String mobile2 = 'assets/images/3x/mobile_2.png';
  static const String addIcon = 'assets/images/3x/addIcon.png';
}
