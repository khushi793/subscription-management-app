part of 'resources.dart';

class SubData {
  SubData._();

  static const String iconss = 'assets/json/iconss.json';
  static const String categoryIcon = 'assets/json/categoryIcon.json';
}
