part 'assets.dart';

part 'app_icons_assets.dart';

part 'sub_data.dart';
